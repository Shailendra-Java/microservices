package com.esquare.RestfulWebServices.hellojava;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {

	@RequestMapping(method=RequestMethod.GET, path="/")
	public String sayHello(){
		return "Hello JAVA";
	}
	
	@GetMapping(path="/hello-java-bean")
	public HelloJavaBean sayHelloBean(){
		return new HelloJavaBean("Hello JAVA Bean");
	}
	
	@GetMapping(path="/hello-java-bean/path-variable/{name}")
	public HelloJavaBean sayHelloBeanPathVariable(@PathVariable String name){
		return new HelloJavaBean(String.format("Hello Java, %s", name));
	}
}
