package com.esquare.RestfulWebServices.hellojava;

public class HelloJavaBean {

	private String message;

	public HelloJavaBean(String message) {
		this.message = message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "HelloJavaBean [message=" + message + "]";
	}

}
